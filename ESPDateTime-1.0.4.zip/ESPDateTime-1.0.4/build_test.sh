#!/bin/bash
pio run --environment nodemcu32s && pio run --environment nodemcuv2
