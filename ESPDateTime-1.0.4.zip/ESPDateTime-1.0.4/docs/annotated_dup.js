var annotated_dup =
[
    [ "DateFormatter", "struct_date_formatter.html", null ],
    [ "DateTimeClass", "class_date_time_class.html", "class_date_time_class" ],
    [ "DateTimeParts", "struct_date_time_parts.html", "struct_date_time_parts" ],
    [ "TimeElapsed", "class_time_elapsed.html", "class_time_elapsed" ]
];